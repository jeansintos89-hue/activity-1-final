<?php
$conn = mysqli_connect("localhost", "root", "", "managementsystem");


?>